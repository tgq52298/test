<?php
namespace app\cms\index;

use app\index\controller\Labelmodels AS _Labelmodels;

class Labelmodels extends _Labelmodels
{  
}
