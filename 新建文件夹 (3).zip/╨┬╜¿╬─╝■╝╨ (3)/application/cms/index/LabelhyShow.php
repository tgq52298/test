<?php
namespace app\cms\index;
use app\index\controller\LabelhyShow AS _LabelhyShow;
class LabelhyShow extends _LabelhyShow
{
}