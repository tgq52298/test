<?php
namespace app\cms\index;

use app\common\controller\index\Index AS _Index;

//频道主页
class Index extends _Index
{
	public function index(){
	    return parent::index();
	}

}
