<?php
namespace app\cms\index;

use app\common\controller\index\Search AS _Search;

//搜索页
class Search extends _Search
{
    
}
