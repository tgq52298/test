<?php
namespace app\cms\index\wxapp;

use app\common\controller\index\wxapp\Api AS _Api; 

//常用接口
class Api extends _Api
{

}













