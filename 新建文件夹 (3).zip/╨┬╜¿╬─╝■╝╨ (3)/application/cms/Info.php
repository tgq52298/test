<?php
namespace app\cms;

class Info{
	public static $keyword;    //关键字，也是目录名
	
	
	
}