<?php
namespace app\cms\member;

use app\common\controller\member\Mysort AS _Mysort;

class Mysort extends _Mysort
{
}