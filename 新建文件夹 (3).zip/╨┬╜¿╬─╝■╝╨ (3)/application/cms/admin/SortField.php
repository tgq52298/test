<?php
namespace app\cms\admin;

use app\common\controller\admin\SortField AS _SortField;

class SortField extends _SortField
{
}
