<?php
namespace app\cms\admin;

use app\common\controller\admin\M;

class Module extends M
{

}
