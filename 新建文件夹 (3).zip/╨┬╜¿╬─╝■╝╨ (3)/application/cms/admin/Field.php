<?php
namespace app\cms\admin;

use app\common\controller\admin\F;

class Field extends F
{
}
