<?php
namespace app\cms\admin;

use app\common\controller\admin\C;
use app\cms\traits\Content AS TraitsContent;


class Content extends C
{	
    use TraitsContent;
}
