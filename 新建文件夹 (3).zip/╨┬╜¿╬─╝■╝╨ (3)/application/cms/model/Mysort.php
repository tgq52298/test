<?php
namespace app\cms\model;
use app\common\model\Mysort AS _Mysort;


class Mysort extends _Mysort
{
}