<?php

namespace app\cms\model;

use app\common\model\S;


class Sort extends S
{
}
