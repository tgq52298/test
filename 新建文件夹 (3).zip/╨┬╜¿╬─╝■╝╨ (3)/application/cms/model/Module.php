<?php

namespace app\cms\model;
use app\common\model\M;

//万能表单模型
class Module extends M
{
}