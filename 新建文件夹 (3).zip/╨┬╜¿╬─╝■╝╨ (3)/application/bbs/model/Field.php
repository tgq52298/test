<?php
namespace app\bbs\model;

use app\common\model\F;


//表单模型字段处理
class Field extends F
{
}