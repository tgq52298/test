<?php

namespace app\bbs\model;

use app\common\model\S;


class Sort extends S
{
}
