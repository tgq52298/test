<?php 
namespace app\bbs\install;

use app\common\controller\AdminBase;


class Install extends AdminBase{
    public function run($id=0){
        
    }
}