<?php 
namespace app\bbs\install;

use app\common\controller\AdminBase;


class Uninstall extends AdminBase{
    public function run($id=0){
        
    }
}