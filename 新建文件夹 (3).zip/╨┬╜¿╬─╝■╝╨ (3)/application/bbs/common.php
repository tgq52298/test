<?php

//
if (!function_exists('update_infomsg')) {
    /**
     * 更新辅助信息
     * @param array $info
     * @return string
     */
//     function update_infomsg($info=[])
// 	{
	    
//     }
 }

 