ALTER TABLE  `qb_bbs_content1` ADD  `font_color` VARCHAR( 7 ) NOT NULL COMMENT  '标题字体颜色',ADD  `font_type` TINYINT( 1 ) NOT NULL COMMENT  '标题字体加粗或其它';
