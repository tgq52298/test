<?php
namespace app\bbs\admin;

use app\common\controller\admin\Reply AS _Reply;


class Reply extends _Reply
{
}













