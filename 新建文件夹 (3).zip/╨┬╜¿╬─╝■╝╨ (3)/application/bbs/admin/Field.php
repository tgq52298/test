<?php
namespace app\bbs\admin;

use app\common\controller\admin\F;

class Field extends F
{
}
