<?php
namespace app\bbs\admin;

use app\common\controller\admin\M;

class Module extends M
{

}
