<?php
namespace app\bbs\admin;

use app\common\controller\admin\Info AS _Info;

//辅栏目内容表
class Info extends _Info
{
	
}













