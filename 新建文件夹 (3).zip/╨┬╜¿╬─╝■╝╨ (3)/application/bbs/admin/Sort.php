<?php
namespace app\bbs\admin;

use app\common\controller\admin\S;


class Sort extends S
{
}













