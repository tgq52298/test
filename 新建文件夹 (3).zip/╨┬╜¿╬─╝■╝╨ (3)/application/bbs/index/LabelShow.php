<?php
namespace app\bbs\index;
use app\index\controller\LabelShow AS _LabelShow;
class LabelShow extends _LabelShow
{
}