<?php
namespace app\bbs\index;

use app\common\controller\index\Labelhy AS _Label;

//标签设置
class Labelhy extends _Label
{
    /**
     * 通用标签设置
     * {@inheritDoc}
     * @see \app\common\controller\index\Labelhy::tag_set()
     */
    public function tag_set(){
        return parent::tag_set();
    }
}













