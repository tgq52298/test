<?php
namespace app\bbs\index;
use app\index\controller\LabelhyShow AS _LabelhyShow;
class LabelhyShow extends _LabelhyShow
{
}