<?php
namespace app\bbs\index;

use app\common\controller\index\Category AS _Category;

//辅栏目
class Category extends _Category
{
    public function index($fid)
    {
        return parent::index($fid);
    }
}













