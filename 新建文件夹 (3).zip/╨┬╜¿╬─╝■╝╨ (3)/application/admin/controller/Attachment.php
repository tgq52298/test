<?php
namespace app\admin\controller;

use app\index\controller\Attachment AS _Attachment;
/**
 * 附件控制器
 * @package app\admin\controller
 */
class Attachment extends _Attachment
{

}