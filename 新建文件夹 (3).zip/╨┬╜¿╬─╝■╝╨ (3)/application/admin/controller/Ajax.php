<?php

namespace app\admin\controller;

use app\index\controller\Ajax as _Ajax;

/**
 * 用于处理ajax请求的控制器
 * @package app\admin\controller
 */
class Ajax extends _Ajax
{

}