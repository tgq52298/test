<?php

namespace app\admin\model;
use think\Model;


//单篇文章独立页
class Alonepage extends Model
{
	
    // 设置当前模型对应的完整数据表名称
    //protected $table = '__MONEYLOG__';
    // 自动写入时间戳
    protected $autoWriteTimestamp = false;
	//主键不是ID,要单独指定
	//protected $pk = 'id';

	
}