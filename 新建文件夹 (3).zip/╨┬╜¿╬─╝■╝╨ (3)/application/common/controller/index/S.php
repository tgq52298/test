<?php
namespace app\common\controller\index;

use app\common\controller\IndexBase;

abstract class S extends IndexBase
{
    
}