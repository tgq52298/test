ALTER TABLE  `qb_memberdata` ADD  `introducer_num` MEDIUMINT( 5 ) NOT NULL COMMENT  '直接推荐用户数',ADD  `introducer_nums` MEDIUMINT( 5 ) NOT NULL COMMENT  '间接推荐用户数';
