ALTER TABLE  `qb_memberdata` ADD  `view` MEDIUMINT( 7 ) NOT NULL COMMENT  '浏览量';
