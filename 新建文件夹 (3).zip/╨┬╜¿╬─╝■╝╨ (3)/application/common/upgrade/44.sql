ALTER TABLE  `qb_shop_content1` ADD  `order_num` MEDIUMINT( 7 ) NOT NULL COMMENT  '下订数量,不确定是否已付款',ADD  `pay_num` MEDIUMINT( 7 ) NOT NULL COMMENT  '付款数量';
