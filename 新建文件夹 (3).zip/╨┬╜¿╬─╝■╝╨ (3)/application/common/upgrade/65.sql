ALTER TABLE  `qb_market` ADD  `name` VARCHAR( 255 ) NOT NULL COMMENT  '名称';
