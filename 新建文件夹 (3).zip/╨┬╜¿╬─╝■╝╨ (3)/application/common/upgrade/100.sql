ALTER TABLE  `qb_memberdata` CHANGE  `money`  `money` MEDIUMINT( 7 ) NOT NULL DEFAULT  '0' COMMENT  '会员积分数';
