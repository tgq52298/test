UPDATE  `qb_module` SET  `version_id` =  '232' WHERE  `keywords` =  'shop' AND  `version_id` =0;
