INSERT INTO `qb_hook` (`id`, `name`, `about`, `ifopen`, `list`) VALUES(0, 'layout_body_foot', '前台布局模板底部', 1, 0);
INSERT INTO `qb_hook` (`id`, `name`, `about`, `ifopen`, `list`) VALUES(0, 'layout_body', '前台布局模板版权信息之上', 1, 0);
INSERT INTO `qb_hook` (`id`, `name`, `about`, `ifopen`, `list`) VALUES(0, 'layout_body_head', '前台布局模板头部', 1, 0);