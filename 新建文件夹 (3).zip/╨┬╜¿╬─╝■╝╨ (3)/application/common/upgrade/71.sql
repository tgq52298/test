UPDATE `qb_config` SET `options`= 'app\\common\\util\\Style@get_indexstyle_template@["layout","wap"]' WHERE `c_key`='module_wap_default_layout';
