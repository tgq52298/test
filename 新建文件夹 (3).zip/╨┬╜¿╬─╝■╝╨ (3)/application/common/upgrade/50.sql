INSERT INTO `qb_config` (`id`, `type`, `title`, `c_key`, `c_value`, `form_type`, `options`, `ifsys`, `htmlcode`, `c_descrip`, `list`, `sys_id`) VALUES(0, 8, '是否限制一个微信号只能注册一个帐号', 'weixin_reg_onlyone', '0', 'radio', '0|不限制\r\n1|只能注册一个帐号', 1, '', '需要启用微信公众号获取验证码才有效', 0, 0);

