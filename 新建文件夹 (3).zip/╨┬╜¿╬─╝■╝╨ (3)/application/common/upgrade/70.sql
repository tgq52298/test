ALTER TABLE  `qb_webmenu` CHANGE  `style`  `style` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT  '' COMMENT  'CSS类名';
ALTER TABLE  `qb_admin_menu` CHANGE  `style`  `style` VARCHAR( 100 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT  '' COMMENT  'CSS类名';
