UPDATE  `qb_module` SET  `version_id` =  '2' WHERE `keywords` = 'form';
UPDATE  `qb_module` SET  `version_id` =  '3' WHERE `keywords` = 'links';
UPDATE  `qb_module` SET  `version_id` =  '5' WHERE `keywords` = 'bbs';
UPDATE  `qb_module` SET  `version_id` =  '6' WHERE `keywords` = 'hongbao';
UPDATE  `qb_module` SET  `version_id` =  '9' WHERE `keywords` = 'qiniu';
UPDATE  `qb_module` SET  `version_id` =  '11' WHERE `keywords` = 'search';