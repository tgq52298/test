UPDATE `qb_chatmod` SET type=0 WHERE pcwap=1 AND keywords='uploadpic';
UPDATE `qb_chatmod` SET type=0 WHERE pcwap=1 AND keywords='sound';
