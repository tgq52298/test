ALTER TABLE  `qb_comment_content` ADD  `tid` INT( 7 ) NOT NULL COMMENT  '一般为空,个别情况,比如工单的话,要对订单进行评论的时候,就这个为内容的ID';
