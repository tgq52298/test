ALTER TABLE  `qb_cms_content1` ADD INDEX (  `uid` );
ALTER TABLE  `qb_cms_content2` ADD INDEX (  `uid` );
ALTER TABLE  `qb_cms_content3` ADD INDEX (  `uid` );
ALTER TABLE  `qb_cms_content4` ADD INDEX (  `uid` );


ALTER TABLE  `qb_shop_content1` ADD INDEX (  `uid` );
