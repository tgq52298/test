ALTER TABLE  `qb_rmb_infull` ADD  `s_orderid` VARCHAR( 32 ) NOT NULL COMMENT  '微信或支付宝生成的订单ID';

