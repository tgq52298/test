ALTER TABLE `qb_comment_content` ADD INDEX ( `uid` );

ALTER TABLE  `qb_bbs_reply` ADD INDEX  `uid` (  `uid` );