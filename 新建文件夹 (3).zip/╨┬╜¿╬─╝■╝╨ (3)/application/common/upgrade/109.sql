ALTER TABLE  `qb_memberdata` ADD  `ext_field` TEXT NOT NULL COMMENT  '用户扩展字段';
