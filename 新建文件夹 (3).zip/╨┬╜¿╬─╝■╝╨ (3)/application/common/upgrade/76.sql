ALTER TABLE  `qb_msg` ADD INDEX (  `create_time` );
