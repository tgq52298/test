<?php
namespace app\bespeak\model;

use app\common\model\C;

//模型内容处理
class Content extends C
{
}
