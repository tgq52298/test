<?php

namespace app\bespeak\model;

use app\common\model\Category AS _Category;


//辅栏目
class Category extends _Category
{
}
