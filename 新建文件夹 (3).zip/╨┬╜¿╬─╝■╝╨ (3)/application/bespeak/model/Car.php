<?php
namespace app\bespeak\model;
use app\common\model\Car AS _Car;


class Car extends _Car
{
}