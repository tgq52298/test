<?php

namespace app\bespeak\model;

use app\common\model\S;


//万能表单模型
class Sort extends S
{
}
