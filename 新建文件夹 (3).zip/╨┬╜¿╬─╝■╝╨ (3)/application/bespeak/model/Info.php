<?php

namespace app\bespeak\model;

use app\common\model\Info AS _Info;


//辅栏目里的内容
class Info extends _Info
{
}
