<?php
namespace app\bespeak\model;

use app\common\model\M;

//表单模型
class Module extends M
{
}