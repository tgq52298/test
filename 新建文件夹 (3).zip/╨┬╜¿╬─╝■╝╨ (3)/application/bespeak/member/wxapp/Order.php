<?php
namespace app\bespeak\member\wxapp;

use app\common\controller\member\wxapp\Order AS _Order;

class Order extends _Order
{
}