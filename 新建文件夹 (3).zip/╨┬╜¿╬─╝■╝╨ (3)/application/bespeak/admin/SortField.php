<?php
namespace app\bespeak\admin;

use app\common\controller\admin\SortField AS _SortField;

class SortField extends _SortField
{
}
