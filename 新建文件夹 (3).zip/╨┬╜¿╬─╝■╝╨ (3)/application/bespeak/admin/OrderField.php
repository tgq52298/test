<?php
namespace app\bespeak\admin;

use app\common\controller\admin\OrderField AS _OrderField;

class OrderField extends _OrderField
{
}
