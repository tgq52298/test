<?php
namespace app\bespeak\admin;

use app\common\controller\admin\Category AS _Category;



//辅栏目
class Category extends _Category
{
    
}












