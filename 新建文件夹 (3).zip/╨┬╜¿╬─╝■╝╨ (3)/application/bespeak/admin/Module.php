<?php
namespace app\bespeak\admin;

use app\common\controller\admin\M;

class Module extends M
{
}
