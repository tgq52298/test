<?php 
namespace app\cms\install;

use app\common\controller\AdminBase;


class Copyinstall extends AdminBase{
    public function run($id=0){
        
    }
}