<?php
namespace app\bespeak\index;
use app\common\controller\index\Labelhy AS _Label;
class Labelhy extends _Label
{
}