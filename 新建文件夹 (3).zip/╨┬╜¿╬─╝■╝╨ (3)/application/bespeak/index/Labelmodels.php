<?php
namespace app\bespeak\index;
use app\index\controller\Labelmodels AS _Labelmodels;
class Labelmodels extends _Labelmodels
{  
}